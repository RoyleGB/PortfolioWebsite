THIS GAME IS CREATED BY JORDAN ROYLE
Student ID: 22476491

Notes: 
       Please read the sound file note inside the 'SpaceShooter' 
       to install the sound import to start the game up.


BUGS:
	The highscore will print in the text file multiple times, 
	however it will still track the highest score and reverse the array, so
	the biggest number will always be shown.

	The leaderboards will only display the top score as it will display 5 
	of the same score because of reason above.

	Sometimes the try again button will either reset the game or take the
	player to the main menu, this is due to the "play" button and "try again"
	button having the same positioning and hitbox parameters.
